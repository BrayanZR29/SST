# DIAGRAMA DE SECUENCIAS
## SST-Registro - Flujos de Interacción

---

## 1. Secuencia: Login

```
┌──────────┐    ┌──────────────┐    ┌──────────────┐    ┌────────────┐
│  Usuario  │    │ LoginController│    │ UsuarioService│    │    BD      │
└────┬─────┘    └───────┬───────┘    └───────┬───────┘    └─────┬──────┘
     │                  │                     │                 │
     │ GET /login        │                     │                 │
     │──────────────────>│                     │                 │
     │                  │                     │                 │
     │ Mostrar form     │                     │                 │
     │<──────────────────│                     │                 │
     │                  │                     │                 │
     │ POST /login      │                     │                 │
     │ correo, pass     │                     │                 │
     │──────────────────>│                     │                 │
     │                  │                     │                 │
     │                  │ buscarPorCorreo()    │                 │
     │                  │─────────────────────>│                 │
     │                  │                     │                 │
     │                  │                     │ SELECT * FROM   │
     │                  │                     │ usuario WHERE   │
     │                  │                     │ correo=?        │
     │                  │                     │────────────────>│
     │                  │                     │                 │
     │                  │                     │   Usuario / null│
     │                  │                     │<────────────────│
     │                  │                     │                 │
     │                  │  ¿Usuario existe && │                 │
     │                  │  password coincide?   │                 │
     │                  │                     │                 │
     │                  │  true/false          │                 │
     │                  │<─────────────────────│                 │
     │                  │                     │                 │
     │  Redirect /      │                     │                 │
     │  dashboard       │                     │                 │
     │<──────────────────│                     │                 │
     │                  │                     │                 │
     │  ERROR: Credenciales│                   │                 │
     │  inválidas       │                     │                 │
     │<──────────────────│                     │                 │
     │                  │                     │                 │
└────┴─────┘    └───────┴───────┘    └───────┴───────┘    └─────┴──────┘
```

---

## 2. Secuencia: Registrar Evento

```
┌──────────┐    ┌──────────────┐    ┌──────────────┐    ┌────────────┐
│  Usuario  │    │ EventoController│   │ EventoService │    │    BD      │
└────┬─────┘    └───────┬───────┘    └───────┬───────┘    └─────┬──────┘
     │                  │                     │                 │
     │ GET /evento/nuevo│                     │                 │
     │──────────────────>│                     │                 │
     │                  │                     │                 │
     │ Mostrar form     │                     │                 │
     │<──────────────────│                     │                 │
     │                  │                     │                 │
     │ POST /evento/    │                     │                 │
     │ guardar          │                     │                 │
     │ datos del form    │                     │                 │
     │──────────────────>│                     │                 │
     │                  │                     │                 │
     │                  │ guardar(EventoDTO)   │                 │
     │                  │─────────────────────>│                 │
     │                  │                     │                 │
     │                  │                     │ generarCodigo() │
     │                  │                     │                 │
     │                  │                     │ INSERT evento   │
     │                  │                     │────────────────>│
     │                  │                     │                 │
     │                  │                     │   evento.id     │
     │                  │                     │<────────────────│
     │                  │                     │                 │
     │                  │ eventoGuardado       │                 │
     │                  │<─────────────────────│                 │
     │                  │                     │                 │
     │ Redirect: /      │                     │                 │
     │ evento/lista     │                     │                 │
     │<──────────────────│                     │                 │
     │                  │                     │                 │
└────┴─────┘    └───────┴───────┘    └───────┴───────┘    └─────┴──────┘
```

---

## 3. Secuencia: Registrar Investigación

```
┌──────────┐    ┌──────────────┐    ┌──────────────┐    ┌────────────┐
│  Usuario  │    │Investigacion│    │ Investigacion│   │    BD      │
│           │    │ Controller   │    │   Service    │    │            │
└────┬─────┘    └───────┬───────┘    └───────┬───────┘    └─────┬──────┘
     │                  │                     │                 │
     │ GET /evento/     │                     │                 │
     │ {id}/investigacion│                    │                 │
     │──────────────────>│                     │                 │
     │                  │                     │                 │
     │ Mostrar form     │                     │                 │
     │ investigación    │                     │                 │
     │<──────────────────│                     │                 │
     │                  │                     │                 │
     │ POST /investigac/│                     │                 │
     │ guardar          │                     │                 │
     │ datos form       │                     │                 │
     │──────────────────>│                     │                 │
     │                  │                     │                 │
     │                  │ guardar(InvDTO)      │                 │
     │                  │─────────────────────>│                 │
     │                  │                     │                 │
     │                  │ Buscar evento       │                 │
     │                  │                     │                 │
     │                  │ INSERT investigacion│                 │
     │                  │                     │────────────────>│
     │                  │                     │                 │
     │                  │                     │ UPDATE evento   │
     │                  │                     │ estado=EN_PROCESO│
     │                  │                     │────────────────>│
     │                  │                     │                 │
     │                  │ investigacionGuardada│                 │
     │                  │<─────────────────────│                 │
     │                  │                     │                 │
     │ Redirect: detalle│                     │                 │
     │ evento/{id}      │                     │                 │
     │<──────────────────│                     │                 │
     │                  │                     │                 │
└────┴─────┘    └───────┴───────┘    └───────┴───────┘    └─────┴────┘
```

---

## 4. Secuencia: Cerrar Caso

```
┌──────────┐    ┌──────────────┐    ┌──────────────┐    ┌────────────┐
│  Usuario  │    │ EventoController│   │ EventoService │    │    BD      │
└────┬─────┘    └───────┬───────┘    └───────┬───────┘    └─────┬──────┘
     │                  │                     │                 │
     │ POST /evento/    │                     │                 │
     │ {id}/cerrar      │                     │                 │
     │──────────────────>│                     │                 │
     │                  │                     │                 │
     │                  │ cerrarCaso(id)       │                 │
     │                  │─────────────────────>│                 │
     │                  │                     │                 │
     │                  │ Verificar acciones  │                 │
     │                  │                     │                 │
     │                  │ ¿Todas completadas? │                 │
     │                  │                     │                 │
     │                  │   [SI]               │                 │
     │                  │                     │                 │
     │                  │ UPDATE evento SET   │                 │
     │                  │ estado=CERRADO       │                 │
     │                  │                     │────────────────>│
     │                  │                     │                 │
     │                  │                     │                 │
     │                  │ casoCerrado          │                 │
     │                  │<─────────────────────│                 │
     │                  │                     │                 │
     │  Redirect:       │                     │                 │
     │  /evento/{id}    │                     │                 │
     │<──────────────────│                     │                 │
     │                  │                     │                 │
     │  [NO] - Error:   │                     │                 │
     │  Hay acciones   │                     │                 │
     │  pendientes      │                     │                 │
     │<──────────────────│                     │                 │
     │                  │                     │                 │
└────┴─────┘    └───────┴───────┘    └───────┴───────┘    └─────┴──────┘
```

---

## 5. Secuencia: Ver Estadísticas

```
┌──────────┐    ┌──────────────┐    ┌──────────────┐    ┌────────────┐
│  Usuario  │    │ Estadistica  │    │ Estadistica   │    │    BD      │
│           │    │ Controller   │    │   Service     │    │            │
└────┬─────┘    └───────┬───────┘    └───────┬───────┘    └─────┬──────┘
     │                  │                     │                 │
     │ GET /estadisticas│                     │                 │
     │ ?periodo=anio    │                     │                 │
     │──────────────────>│                     │                 │
     │                  │                     │                 │
     │                  │ obtenerEstadisticas()│                │
     │                  │ período=anio        │                 │
     │                  │─────────────────────>│                 │
     │                  │                     │                 │
     │                  │                     │ SELECT COUNT(*) │
     │                  │                     │ FROM evento     │
     │                  │                     │ GROUP BY tipo   │
     │                  │                     │────────────────>│
     │                  │                     │                 │
     │                  │                     │   datos         │
     │                  │                     │<────────────────│
     │                  │                     │                 │
     │                  │ estadisticaDTO       │                 │
     │                  │<─────────────────────│                 │
     │                  │                     │                 │
     │ Mostrar gráficos │                     │                 │
     │ con datos        │                     │                 │
     │<──────────────────│                     │                 │
     │                  │                     │                 │
└────┴─────┘    └───────┴───────┘    └───────┴───────┘    └─────┴────┘
```

---

## 6. Secuencia: Exportar PDF

```
┌──────────┐    ┌──────────────┐    ┌──────────────┐    ┌────────────┐
│  Usuario  │    │   Reporte   │    │  Reporte      │    │    BD      │
│           │    │  Controller  │    │   Service    │    │            │
└────┬─────┘    └───────┬───────┘    └───────┬───────┘    └─────┬──────┘
     │                  │                     │                 │
     │ GET /reporte/    │                     │                 │
     │ evento/{id}/pdf  │                     │                 │
     │──────────────────>│                     │                 │
     │                  │                     │                 │
     │                  │ generarReportePDF() │                 │
     │                  │─────────────────────>│                 │
     │                  │                     │                 │
     │                  │ Buscar datos evento  │                 │
     │                  │                     │                 │
     │                  │ Crear documento     │                 │
     │                  │ con iText/Jasper    │                 │
     │                  │                     │                 │
     │                  │                     │                 │
     │  FILE PDF        │                     │                 │
     │<──────────────────│                     │                 │
     │                  │                     │                 │
└────┴─────┘    └───────┴───────┘    └───────┴───────┘    └─────┴────┘
```

---
